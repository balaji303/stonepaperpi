import cv2
import os

cam = cv2.VideoCapture(0)
cv2.namedWindow("StonePaperPi")
img_counter = 0
currentDir = os.path.dirname(__file__)
print(currentDir)
os.chdir(currentDir)